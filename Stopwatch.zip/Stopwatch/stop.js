document.addEventListener("DOMContentLoaded", function() {
  let hours = 0;
  let minutes = 0;
  let seconds = 0;
  let interval;

  const hoursElement = document.getElementById("hours");
  const minutesElement = document.getElementById("minutes");
  const secondsElement = document.getElementById("seconds");
  const startButton = document.getElementById("start-button");
  const stopButton = document.getElementById("stop-button");
  const resetButton = document.getElementById("reset-button");

  function startStopwatch() {
    interval = setInterval(function() {
      seconds++;
      if (seconds === 60) {
        seconds = 0;
        minutes++;
        if (minutes === 60) {
          minutes = 0;
          hours++;
        }
      }
      updateDisplay();
    }, 1000);
    startButton.disabled = true;
    stopButton.disabled = false;
  }

  function stopStopwatch() {
    clearInterval(interval);
    startButton.disabled = false;
    stopButton.disabled = true;
  }

  function resetStopwatch() {
    clearInterval(interval);
    hours = 0;
    minutes = 0;
    seconds = 0;
    updateDisplay();
    startButton.disabled = false;
    stopButton.disabled = true;
  }

  function updateDisplay() {
    hoursElement.textContent = hours.toString().padStart(2, '0');
    minutesElement.textContent = minutes.toString().padStart(2, '0');
    secondsElement.textContent = seconds.toString().padStart(2, '0');
  }

  startButton.addEventListener("click", startStopwatch);
  stopButton.addEventListener("click", stopStopwatch);
  resetButton.addEventListener("click", resetStopwatch);
});
